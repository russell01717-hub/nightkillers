"""
╔══════════════════════════════════════════╗
║        NIGHT KILLERS - MAFIA BOT         ║
║        Aiogram 3.x asosida yozilgan      ║
╚══════════════════════════════════════════╝

Muallif: @russell01717
Versiya: 3.0
Texnologiya: aiogram 3.x + SQLite
"""

# ═══════════════════════════════════════════
#  1. IMPORTS
# ═══════════════════════════════════════════
import asyncio
import logging
import random
import sqlite3
import json
import os
import sys
from datetime import datetime, timedelta
from typing import Dict, Optional, List, Any, Tuple

# Aiogram kutubxonasini yuklash
try:
    sys.path.insert(0, r"D:\pylibs")
except:
    pass

from aiogram import Bot, Dispatcher, types, F
from aiogram.client.default import DefaultBotProperties
from aiogram.filters import Command, CommandObject
from aiogram.types import (
    InlineKeyboardButton, InlineKeyboardMarkup,
    CallbackQuery, Message, ChatMemberUpdated
)
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.utils.keyboard import InlineKeyboardBuilder

# ═══════════════════════════════════════════
#  2. KONFIGURATSIYA
# ═══════════════════════════════════════════

TOKEN = os.environ["BOT_TOKEN"]  # Token faqat muhit o'zgaruvchisidan olinadi
ADMIN_ID = 7820231987            # Bot adminining Telegram ID si
MAX_PLAYERS = 100                # Maksimal o'yinchilar soni
MIN_PLAYERS = 4                  # Minimal o'yinchilar soni
NIGHT_TIME = 45                  # Tun fazasi davomiyligi (soniya)
DAY_TIME = 45                    # Kun (ovoz berish) davomiyligi (soniya)

# Ma'lumotlar bazasi fayli
DB_PATH = os.path.join(os.path.dirname(__file__), "mafia.db")

# Rollar va ularning belgilari
ROLE_ICON = {
    "Mafia": "🔪",
    "Don": "👑",
    "Komissar": "🔍",
    "Doktor": "💊",
    "Tinch aholi": "👤"
}

ROLE_DISPLAY = {
    "Mafia": "Mafia (🔪)",
    "Don": "Don (👑)",
    "Komissar": "Komissar (🔍)",
    "Doktor": "Doktor (💊)",
    "Tinch aholi": "Tinch aholi (👤)"
}

ROLE_TEAM = {
    "Mafia": "mafia",
    "Don": "mafia",
    "Komissar": "village",
    "Doktor": "village",
    "Tinch aholi": "village"
}

ROLE_DESC = {
    "Mafia": "Tun bo'yi boshqa mafiya a'zolari bilan kimni o'ldirishni tanlaysiz",
    "Don": "Mafiya boshlig'i. Sizning ovozingiz hal qiluvchi",
    "Komissar": "Tun bo'yi bir o'yinchini tekshirib, uning mafiya yoki tinch aholi ekanligini bilib olasiz",
    "Doktor": "Tun bo'yi bir o'yinchini davolaysiz. Agar mafiya o'sha odamni otgan bo'lsa, u tirik qoladi",
    "Tinch aholi": "Tun bo'yi uxlaysiz. Kunning yorishini kutasiz"
}

# ═══════════════════════════════════════════
#  3. GLOBAL O'ZGARUVCHILAR
# ═══════════════════════════════════════════

games: Dict[int, "MafiaGame"] = {}           # Faol o'yinlar: {chat_id: MafiaGame}
weekly_titles: Dict[int, str] = {}           # Haftalik unvonlar: {user_id: title}
bot_instance: Optional[Bot] = None           # Bot instansiyasi (global)
dp_instance: Optional[Dispatcher] = None     # Dispatcher instansiyasi (global)

# ═══════════════════════════════════════════
#  4. MA'LUMOTLAR BAZASI (SQLite)
# ═══════════════════════════════════════════

def init_db():
    """Ma'lumotlar bazasini yaratish. 
    Agar jadvallar mavjud bo'lmasa, ularni yaratadi."""
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        
        conn.execute("""
            CREATE TABLE IF NOT EXISTS profiles (
                user_id INTEGER PRIMARY KEY,
                name TEXT DEFAULT '',
                username TEXT DEFAULT '',
                olmos INTEGER DEFAULT 0,
                dollars INTEGER DEFAULT 0,
                evro INTEGER DEFAULT 0,
                games INTEGER DEFAULT 0,
                wins INTEGER DEFAULT 0,
                losses INTEGER DEFAULT 0,
                bought_role TEXT DEFAULT NULL,
                hero INTEGER DEFAULT 0
            )
        """)
        
        conn.execute("""
            CREATE TABLE IF NOT EXISTS weekly_scores (
                user_id INTEGER,
                week_num INTEGER,
                score INTEGER DEFAULT 0,
                PRIMARY KEY (user_id, week_num)
            )
        """)
        
        conn.execute("""
            CREATE TABLE IF NOT EXISTS weekly_titles (
                user_id INTEGER PRIMARY KEY,
                title TEXT DEFAULT '',
                week_num INTEGER DEFAULT 0
            )
        """)
        
        conn.execute("""
            CREATE TABLE IF NOT EXISTS chat_settings (
                chat_id INTEGER PRIMARY KEY,
                min_players INTEGER DEFAULT 4,
                night_time INTEGER DEFAULT 45,
                vote_time INTEGER DEFAULT 45,
                mode TEXT DEFAULT 'classic'
            )
        """)
        
        conn.commit()


def get_profile(user_id: int, name: str = "", username: str = "") -> dict:
    """Foydalanuvchi profilini olish. Agar mavjud bo'lmasa, yangi yaratadi."""
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT * FROM profiles WHERE user_id = ?", (user_id,)
        ).fetchone()
        
        if row is None:
            conn.execute(
                "INSERT OR IGNORE INTO profiles (user_id, name, username) VALUES (?, ?, ?)",
                (user_id, name, username)
            )
            conn.commit()
            return {
                "user_id": user_id, "name": name, "username": username,
                "olmos": 0, "dollars": 0, "evro": 0,
                "games": 0, "wins": 0, "losses": 0,
                "bought_role": None, "hero": 0
            }
        
        return dict(row)


def save_profile(user_id: int, data: dict):
    """Foydalanuvchi profilini saqlash."""
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            UPDATE profiles SET
                name = ?, username = ?, olmos = ?, dollars = ?, evro = ?,
                games = ?, wins = ?, losses = ?, bought_role = ?, hero = ?
            WHERE user_id = ?
        """, (
            data.get("name", ""), data.get("username", ""),
            data.get("olmos", 0), data.get("dollars", 0), data.get("evro", 0),
            data.get("games", 0), data.get("wins", 0), data.get("losses", 0),
            data.get("bought_role"), data.get("hero", 0),
            user_id
        ))
        conn.commit()


def update_weekly_score(user_id: int, score_delta: int = 1):
    """Haftalik ballni yangilash."""
    week_num = datetime.now().isocalendar()[1]
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            INSERT INTO weekly_scores (user_id, week_num, score)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id, week_num) DO UPDATE SET
                score = score + ?
        """, (user_id, week_num, score_delta, score_delta))
        conn.commit()


def get_weekly_top(limit: int = 20) -> List[dict]:
    """Haftalik eng yaxshi o'yinchilar ro'yxati."""
    week_num = datetime.now().isocalendar()[1]
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute("""
            SELECT s.user_id, s.score, p.name, p.username
            FROM weekly_scores s
            LEFT JOIN profiles p ON p.user_id = s.user_id
            WHERE s.week_num = ?
            ORDER BY s.score DESC
            LIMIT ?
        """, (week_num, limit)).fetchall()
        return [dict(r) for r in rows]


def get_weekly_titles_dict() -> dict:
    """Haftalik unvonlarni olish."""
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT user_id, title, week_num FROM weekly_titles"
        ).fetchall()
        result = {}
        for r in rows:
            result[r["user_id"]] = {"title": r["title"], "week": r["week_num"]}
        return result


def save_weekly_title(user_id: int, title: str, week_num: int):
    """Haftalik unvonni saqlash."""
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            INSERT OR REPLACE INTO weekly_titles (user_id, title, week_num)
            VALUES (?, ?, ?)
        """, (user_id, title, week_num))
        conn.commit()


def get_chat_setting(chat_id: int, key: str, default=None):
    """Guruh sozlamasini olish."""
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT * FROM chat_settings WHERE chat_id = ?", (chat_id,)
        ).fetchone()
        if row is None:
            return default
        return dict(row).get(key, default)


def set_chat_setting(chat_id: int, key: str, value):
    """Guruh sozlamasini o'rnatish."""
    with sqlite3.connect(DB_PATH) as conn:
        # Ensure row exists
        conn.execute(
            "INSERT OR IGNORE INTO chat_settings (chat_id) VALUES (?)",
            (chat_id,)
        )
        conn.execute(
            f"UPDATE chat_settings SET {key} = ? WHERE chat_id = ?",
            (value, chat_id)
        )
        conn.commit()


# ═══════════════════════════════════════════
#  5. O'YINCHI VA O'YIN KLASSLARI
# ═══════════════════════════════════════════

class Player:
    """Bitta o'yinchining ma'lumotlari"""
    
    def __init__(self, user_id: int, name: str, username: str = ""):
        self.user_id = user_id
        self.name = name
        self.username = username
        self.role = ""          # Mafia, Don, Komissar, Doktor, Tinch aholi
        self.team = ""          # mafia yoki village
        self.alive = True
        self.action = None      # {"type": "kill"/"check"/"heal", "target": user_id}
        self.vote = None        # Kun davomida kimga ovoz bergan (-1 = o'tkazib yuborish)
        self.protected = False  # Doktor tomonidan himoyalangan
    
    @property
    def display(self) -> str:
        """O'yinchining ko'rinadigan nomi"""
        if self.username:
            return f"@{self.username}"
        return self.name


class MafiaGame:
    """Bitta o'yinning holati va mantiqi"""
    
    def __init__(self, chat_id: int):
        self.chat_id = chat_id
        self.phase = "registration"  # registration | night | day | ended
        self.day = 0
        self.players: Dict[int, Player] = {}
        self.action_ready: Dict[int, bool] = {}  # Kim harakat qilgan
        self.night_task: Optional[asyncio.Task] = None
        self.day_task: Optional[asyncio.Task] = None
        self.game_msg_id: Optional[int] = None  # Guruhdagi o'yin xabari ID si
        self.winner: Optional[str] = None       # mafia yoki village
        self.start_time: Optional[float] = None
        
        # Tun natijalari
        self.mafia_votes: Dict[int, int] = {}    # Mafia a'zosi -> target_id
        self.don_target: Optional[int] = None
        self.komissar_target: Optional[int] = None
        self.doktor_target: Optional[int] = None
        self.kill_target: Optional[int] = None   # O'ldirilgan o'yinchi
        self.healed_player: Optional[int] = None  # Davolangan o'yinchi
    
    @property
    def alive_players(self) -> List[Player]:
        """Tirik o'yinchilar ro'yxati"""
        return [p for p in self.players.values() if p.alive]
    
    @property
    def mafia_players(self) -> List[Player]:
        """Tirik mafia guruhi o'yinchilari"""
        return [p for p in self.alive_players if p.team == "mafia"]
    
    @property
    def village_players(self) -> List[Player]:
        """Tirik village guruhi o'yinchilari"""
        return [p for p in self.alive_players if p.team == "village"]
    
    @property
    def mafia_votes_received(self) -> Dict[int, int]:
        """Mafia ovozlarini hisoblash: {target_id: ovoz_soni}"""
        votes = {}
        for target in self.mafia_votes.values():
            votes[target] = votes.get(target, 0) + 1
        # Donning ovozi qo'shimcha
        if self.don_target is not None:
            votes[self.don_target] = votes.get(self.don_target, 0) + 1
        return votes
    
    def get_player(self, user_id: int) -> Optional[Player]:
        """O'yinchini ID bo'yicha topish"""
        return self.players.get(user_id)
    
    def get_roles_text(self) -> str:
        """Barcha o'yinchilarning rollarini matn ko'rinishida qaytarish (o'yin tugagandan keyin)"""
        lines = []
        for p in self.players.values():
            icon = ROLE_ICON.get(p.role, "❓")
            status = "✅" if p.alive else "💀"
            lines.append(f"{status} {p.display}: {icon} {p.role}")
        return "\n".join(lines)
    
    def reset_night(self):
        """Tun boshlanishi uchun barcha o'zgaruvchilarni tozalash"""
        for p in self.players.values():
            p.action = None
            p.protected = False
        self.action_ready = {}
        self.mafia_votes = {}
        self.don_target = None
        self.komissar_target = None
        self.doktor_target = None
        self.kill_target = None
        self.healed_player = None
    
    def reset_day(self):
        """Kun boshlanishi uchun ovozlarni tozalash"""
        for p in self.players.values():
            p.vote = None
        self.action_ready = {}


def distribute_roles(player_count: int) -> List[str]:
    """O'yinchilar soniga qarab rollarni adolatli taqsimlash.
    
    Qoida: Mafia guruhi (Mafia + Don) o'yinchilarning taxminan 1/3 qismini tashkil qiladi.
    """
    roles = []
    
    # Mafia sonini aniqlash
    if player_count <= 6:
        mafia_count = 1
    elif player_count <= 10:
        mafia_count = 2
    elif player_count <= 15:
        mafia_count = 3
    else:
        mafia_count = 4
    
    # Mafia guruhi
    roles.extend(["Mafia"] * mafia_count)
    roles.append("Don")
    
    # Village maxsus rollari
    roles.append("Komissar")
    roles.append("Doktor")
    
    # Qolgan o'yinchilar Tinch aholi
    while len(roles) < player_count:
        roles.append("Tinch aholi")
    
    random.shuffle(roles)
    return roles


# ═══════════════════════════════════════════
#  6. YORDAMCHI FUNKSIYALAR
# ═══════════════════════════════════════════

def make_inline_keyboard(buttons: List[List[InlineKeyboardButton]]) -> InlineKeyboardMarkup:
    """Inline klaviatura yaratish"""
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def make_players_keyboard(
    players: List[Player],
    callback_prefix: str,
    exclude_ids: Optional[set] = None,
    columns: int = 2
) -> InlineKeyboardMarkup:
    """O'yinchilar ro'yxatidan inline tugmalar yaratish.
    
    Parametrlar:
        players: O'yinchilar ro'yxati
        callback_prefix: Tugma callback data prefiksi (masalan: "n_kill", "d_vote")
        exclude_ids: Chiqarib tashlanadigan o'yinchilar ID lari
        columns: Bir qatordagi tugmalar soni
    """
    exclude_ids = exclude_ids or set()
    builder = InlineKeyboardBuilder()
    for p in players:
        if p.user_id not in exclude_ids:
            builder.button(
                text=f"{ROLE_ICON.get(p.role, '👤')} {p.display}" if p.role else p.display,
                callback_data=f"{callback_prefix}:{p.user_id}"
            )
    builder.adjust(columns)
    return builder.as_markup()


async def safe_send_message(
    bot: Bot,
    chat_id: int,
    text: str,
    reply_markup: Optional[InlineKeyboardMarkup] = None,
    parse_mode: str = "HTML"
) -> Optional[Message]:
    """Xavfsiz xabar yuborish. Xatolik yuz bersa, log yozadi va None qaytaradi."""
    try:
        return await bot.send_message(chat_id, text, reply_markup=reply_markup, parse_mode=parse_mode)
    except TelegramForbiddenError:
        logging.warning(f"Bot {chat_id} ga xabar yubora olmadi (bloklangan)")
    except TelegramBadRequest as e:
        logging.warning(f"Xabar yuborishda xatolik: {e}")
    except Exception as e:
        logging.error(f"Kutilmagan xatolik: {e}")
    return None


async def safe_edit_message(
    bot: Bot,
    chat_id: int,
    message_id: int,
    text: Optional[str] = None,
    reply_markup: Optional[InlineKeyboardMarkup] = None,
    parse_mode: str = "HTML"
):
    """Xavfsiz xabarni tahrirlash. Foto yoki animatsiya bo'lsa, caption'ni tahrirlaydi."""
    try:
        if text is not None:
            await bot.edit_message_text(
                text, chat_id=chat_id, message_id=message_id,
                reply_markup=reply_markup, parse_mode=parse_mode
            )
    except TelegramBadRequest:
        # Agar xabarda foto bo'lsa, caption'ni tahrirlaymiz
        try:
            await bot.edit_message_caption(
                chat_id=chat_id, message_id=message_id,
                caption=text, reply_markup=reply_markup,
                parse_mode=parse_mode
            )
        except TelegramBadRequest:
            pass
    except Exception as e:
        logging.error(f"Xabarni tahrirlashda xatolik: {e}")


def check_winner(game: MafiaGame) -> Optional[str]:
    """O'yin g'olibini tekshirish. G'olib bo'lmasa, None qaytaradi.
    
    Qoidalar:
    - Barcha mafiya o'lsa → Village g'alaba qozonadi
    - Mafia soni village soniga teng yoki ko'p bo'lsa → Mafia g'alaba qozonadi
    """
    alive = game.alive_players
    mafia_alive = len([p for p in alive if p.team == "mafia"])
    village_alive = len([p for p in alive if p.team == "village"])
    
    if mafia_alive == 0:
        return "village"
    if mafia_alive >= village_alive:
        return "mafia"
    return None


# ═══════════════════════════════════════════
#  7. REGISTRATSIYA HANDLERLARI
# ═══════════════════════════════════════════

async def cmd_start(message: Message, bot: Bot):
    """Botni ishga tushirish - shaxsiy xabarda menyu ko'rsatish"""
    user = message.from_user
    get_profile(user.id, user.first_name, user.username or "")
    
    text = (
        f"🌙 <b>NIGHT KILLERS</b>\n\n"
        f"Assalomu alaykum, {user.first_name}!\n"
        f"Bu yerda sir, qo'rquv va raqobat hukm suradi.\n\n"
        f"🎯 <b>Nega aynan biz?</b>\n"
        f"• 5 xil rol bilan qiziqarli o'yin tizimi\n"
        f"• Haftalik reyting va noyob unvonlar\n"
        f"• To'liq iqtisod tizimi (olmos, dollar, evro)\n\n"
        f"⚡ <b>O'ynash uchun:</b>\n"
        f"1️⃣ Guruhga botni qo'shing\n"
        f"2️⃣ /mafia yozib o'yin yarating\n"
        f"3️⃣ /join bilan qo'shiling\n"
        f"4️⃣ Admin /startgame bilan o'yinni boshlaydi\n\n"
        f"<i>🌙 Hech kimga ishonma. Har bir zulmatda yashirin dushman bor...</i>"
    )
    
    kb = make_inline_keyboard([
        [InlineKeyboardButton("👤 Profil", callback_data="profile"),
         InlineKeyboardButton("🏆 Reyting", callback_data="top")],
        [InlineKeyboardButton("📊 Statistika", callback_data="stats"),
         InlineKeyboardButton("📖 Yordam", callback_data="help")],
    ])
    
    await message.answer(text, reply_markup=kb, parse_mode="HTML")


async def cmd_mafia(message: Message, bot: Bot):
    """Guruhda yangi o'yin yaratish.
    Faqat guruhlarda ishlaydi. Agar allaqachon o'yin bo'lsa, xatolik qaytaradi."""
    chat_id = message.chat.id
    user_id = message.from_user.id
    
    # Faqat guruhda ishlashi kerak
    if message.chat.type == "private":
        await message.answer("❌ Bu buyruq faqat guruhlarda ishlaydi!")
        return
    
    # Agar allaqachon o'yin mavjud bo'lsa
    if chat_id in games:
        await message.answer("❌ Bu chatda allaqachon o'yin bor!")
        return
    
    # Yangi o'yin yaratish
    game = MafiaGame(chat_id)
    games[chat_id] = game
    
    text = (
        f"🌙 <b>MAFIA O'YINI</b>\n\n"
        f"<b>O'yin yaratildi!</b>\n"
        f"Ro'yxatdan o'tish boshlandi.\n\n"
        f"Qo'shilish uchun /join yoki tugmani bosing.\n"
        f"Minimal: {MIN_PLAYERS} o'yinchi\n\n"
        f"<b>Ro'yhatdan o'tganlar:</b>\n"
        f"Hali hech kim qo'shilgani yo'q."
    )
    
    kb = make_inline_keyboard([
        [InlineKeyboardButton("➕ Qo'shilish", callback_data=f"join:{chat_id}")],
        [InlineKeyboardButton("❌ Chiqish", callback_data=f"leave:{chat_id}")]
    ])
    
    sent = await message.answer(text, reply_markup=kb, parse_mode="HTML")
    game.game_msg_id = sent.message_id


async def cmd_join(message: Message, bot: Bot):
    """O'yinga qo'shilish."""
    chat_id = message.chat.id
    user = message.from_user
    
    if chat_id not in games:
        await message.answer("❌ Bu chatda o'yin mavjud emas! /mafia yozib o'yin yarating.")
        return
    
    game = games[chat_id]
    if game.phase != "registration":
        await message.answer("❌ Ro'yxatdan o'tish tugagan!")
        return
    
    if user.id in game.players:
        await message.answer("❌ Siz allaqachon o'yindasiz!")
        return
    
    if len(game.players) >= MAX_PLAYERS:
        await message.answer("❌ O'yin to'liq!")
        return
    
    game.players[user.id] = Player(user.id, user.first_name, user.username or "")
    await update_game_message(game, bot)
    
    # Shaxsiy xabarga tasdiq yuborish
    try:
        await bot.send_message(
            user.id,
            f"✅ O'yinga qo'shildingiz!\n"
            f"Guruh: {message.chat.title}\n"
            f"O'yin boshlanishini kuting."
        )
    except TelegramForbiddenError:
        pass  # Foydalanuvchi botni bloklagan bo'lishi mumkin


async def cmd_leave(message: Message, bot: Bot):
    """O'yindan chiqish."""
    chat_id = message.chat.id
    user_id = message.from_user.id
    
    if chat_id not in games:
        await message.answer("❌ Bu chatda o'yin mavjud emas!")
        return
    
    game = games[chat_id]
    if game.phase != "registration":
        await message.answer("❌ Ro'yxatdan o'tish tugagan!")
        return
    
    if user_id not in game.players:
        await message.answer("❌ Siz o'yinda emassiz!")
        return
    
    del game.players[user_id]
    await update_game_message(game, bot)
    await message.answer("✅ O'yindan chiqdingiz.")


async def cmd_startgame(message: Message, bot: Bot):
    """O'yinni boshlash (faqat admin yoki o'yin yaratuvchisi)."""
    chat_id = message.chat.id
    user_id = message.from_user.id
    
    if chat_id not in games:
        await message.answer("❌ Bu chatda o'yin mavjud emas!")
        return
    
    game = games[chat_id]
    if game.phase != "registration":
        await message.answer("❌ O'yin allaqachon boshlangan!")
        return
    
    if user_id != ADMIN_ID:
        await message.answer("❌ Faqat admin o'yinni boshlashi mumkin!")
        return
    
    player_count = len(game.players)
    if player_count < MIN_PLAYERS:
        await message.answer(f"❌ Kamida {MIN_PLAYERS} o'yinchi kerak! Hozir: {player_count}")
        return
    
    # Rollarni taqsimlash
    roles = distribute_roles(player_count)
    for player, role in zip(game.players.values(), roles):
        player.role = role
        player.team = ROLE_TEAM.get(role, "village")
    
    # O'yin haqidagi xabarni tahrirlash
    player_list = "\n".join([
        f"• {p.display}" for p in game.players.values()
    ])
    
    text = (
        f"🎮 <b>O'yin boshlandi!</b>\n\n"
        f"<b>O'yinchilar ({player_count}):</b>\n{player_list}\n\n"
        f"🌙 <b>1-tun boshlandi!</b>\n"
        f"Barcha o'yinchilar PM dan rollaringizni tekshiring."
    )
    
    if game.game_msg_id:
        await safe_edit_message(bot, chat_id, game.game_msg_id, text)
    
    # Har bir o'yinchiga rolini yuborish
    for player in game.players.values():
        role_text = (
            f"🌙 <b>NIGHT KILLERS</b>\n\n"
            f"Sizning rolingiz: <b>{ROLE_DISPLAY.get(player.role, player.role)}</b>\n\n"
            f"{ROLE_DESC.get(player.role, '')}\n\n"
        )
        await safe_send_message(bot, player.user_id, role_text, parse_mode="HTML")
    
    # O'yin haqida guruhga xabar
    await message.answer(
        f"🌙 <b>1-tun boshlandi!</b>\n"
        f"Tun davomiyligi: {NIGHT_TIME} soniya\n\n"
        f"Maxsus rollar PM dan harakat qilishingizni kuting.",
        parse_mode="HTML"
    )
    
    # 1-tunni boshlash
    await start_night_phase(game, bot)


async def cmd_cancel(message: Message, bot: Bot):
    """O'yinni bekor qilish (faqat admin)."""
    chat_id = message.chat.id
    user_id = message.from_user.id
    
    if chat_id not in games:
        await message.answer("❌ Bu chatda o'yin mavjud emas!")
        return
    
    if user_id != ADMIN_ID:
        await message.answer("❌ Faqat admin o'yinni bekor qilishi mumkin!")
        return
    
    game = games[chat_id]
    
    # Background tasklarni to'xtatish
    if game.night_task and not game.night_task.done():
        game.night_task.cancel()
    if game.day_task and not game.day_task.done():
        game.day_task.cancel()
    
    del games[chat_id]
    await message.answer("❌ O'yin bekor qilindi.")


async def update_game_message(game: MafiaGame, bot: Bot):
    """O'yin xabarini yangilash (o'yinchilar ro'yxati o'zgarganda)."""
    if not game.game_msg_id:
        return
    
    count = len(game.players)
    player_list = "\n".join([
        f"{i}. {p.display}" for i, p in enumerate(game.players.values(), 1)
    ])
    
    if not player_list:
        player_list = "Hali hech kim qo'shilgani yo'q."
    
    text = (
        f"🌙 <b>MAFIA O'YINI</b>\n\n"
        f"Ro'yxatdan o'tish davom etmoqda.\n\n"
        f"<b>Ro'yhatdan o'tganlar ({count}):</b>\n{player_list}\n\n"
        f"Minimal: {MIN_PLAYERS} o'yinchi"
    )
    
    kb = make_inline_keyboard([
        [InlineKeyboardButton("➕ Qo'shilish", callback_data=f"join:{game.chat_id}")],
        [InlineKeyboardButton("❌ Chiqish", callback_data=f"leave:{game.chat_id}")]
    ])
    
    await safe_edit_message(bot, game.chat_id, game.game_msg_id, text, reply_markup=kb)


# ═══════════════════════════════════════════
#  8. TUN FAZASI
# ═══════════════════════════════════════════

async def start_night_phase(game: MafiaGame, bot: Bot):
    """Tun fazasini boshlash.
    Har bir o'yinchiga mos keladigan inline tugmalarni yuboradi."""
    game.phase = "night"
    game.day += 1
    game.reset_night()
    
    # Mafia guruhiga kimni o'ldirishni so'rash
    mafia_targets = [p for p in game.alive_players if p.team == "village"]
    
    for player in game.alive_players:
        if player.role == "Mafia":
            # Mafia: kimni o'ldirishni tanlaydi
            if mafia_targets:
                kb = make_players_keyboard(mafia_targets, f"nv_kill:{game.day}")
                await safe_send_message(
                    bot, player.user_id,
                    f"🌙 <b>{game.day}-tun</b>\n\nKimni o'ldiramiz?",
                    reply_markup=kb
                )
            game.action_ready[player.user_id] = False
            
        elif player.role == "Don":
            # Don: kimni o'ldirishni tanlaydi
            if mafia_targets:
                kb = make_players_keyboard(mafia_targets, f"nv_don:{game.day}")
                await safe_send_message(
                    bot, player.user_id,
                    f"🌙 <b>{game.day}-tun</b>\n\nKimni o'ldiramiz? (Sizning ovozingiz hal qiluvchi)",
                    reply_markup=kb
                )
            game.action_ready[player.user_id] = False
            
        elif player.role == "Komissar":
            # Komissar: kimni tekshirishni tanlaydi
            check_targets = [p for p in game.alive_players if p.user_id != player.user_id]
            if check_targets:
                kb = make_players_keyboard(check_targets, f"nv_check:{game.day}")
                await safe_send_message(
                    bot, player.user_id,
                    f"🌙 <b>{game.day}-tun</b>\n\nKimni tekshiramiz? 🔍",
                    reply_markup=kb
                )
            game.action_ready[player.user_id] = False
            
        elif player.role == "Doktor":
            # Doktor: kimni davolashni tanlaydi
            heal_targets = game.alive_players
            if heal_targets:
                kb = make_players_keyboard(heal_targets, f"nv_heal:{game.day}")
                await safe_send_message(
                    bot, player.user_id,
                    f"🌙 <b>{game.day}-tun</b>\n\nKimni davolaymiz? 💊",
                    reply_markup=kb
                )
            game.action_ready[player.user_id] = False
            
        else:
            # Tinch aholi: uxlaydi
            text = (
                f"🌙 <b>{game.day}-tun</b>\n\n"
                f"Siz tun bo'yi uxlaysiz... 😴\n"
                f"Tong otishini kuting."
            )
            await safe_send_message(bot, player.user_id, text)
    
    # Tun uchun timer (background task)
    game.night_task = asyncio.create_task(night_timer(game, bot))


async def night_timer(game: MafiaGame, bot: Bot):
    """Tun timer. NIGHT_TIME soniyadan keyin tunni yakunlaydi."""
    try:
        await asyncio.sleep(NIGHT_TIME)
        await end_night_phase(game, bot)
    except asyncio.CancelledError:
        pass  # Kun ertaroq yakunlandi
    except Exception as e:
        logging.error(f"Night timer error: {e}")


async def end_night_phase(game: MafiaGame, bot: Bot):
    """Tun fazasini yakunlash va natijalarni hisoblash."""
    if game.phase != "night":
        return
    
    # Barcha harakatlarni yig'ish
    game.phase = "day"
    
    # Mafia ovozlarini hisoblash
    mafia_votes = game.mafia_votes_received
    if mafia_votes:
        # Eng ko'p ovoz olgan target
        max_votes = max(mafia_votes.values())
        top_targets = [t for t, v in mafia_votes.items() if v == max_votes]
        game.kill_target = random.choice(top_targets)  # Teng bo'lsa, random
    elif game.don_target is not None:
        game.kill_target = game.don_target
    
    # Heal va kill tekshiruvi
    killed_player = None
    if game.kill_target is not None and game.kill_target in game.players:
        target_player = game.get_player(game.kill_target)
        if target_player and target_player.alive:
            if game.kill_target == game.doktor_target:
                # Doktor himoya qildi - hech kim o'lmadi
                game.healed_player = game.kill_target
                target_player.protected = True
            else:
                # O'yinchi o'ladi
                target_player.alive = False
                killed_player = target_player
    
    # Komissar natijasi
    komissar_result = None
    if game.komissar_target is not None and game.komissar_target in game.players:
        checked = game.get_player(game.komissar_target)
        if checked:
            is_mafia = checked.team == "mafia"
            komissar_result = "🔴 MAFIA" if is_mafia else "🟢 Tinch aholi"
            # Komissarga natijani yuborish
            for p in game.players.values():
                if p.role == "Komissar" and p.alive:
                    await safe_send_message(
                        bot, p.user_id,
                        f"🔍 <b>Tekshiruv natijasi:</b>\n{checked.display}: {komissar_result}"
                    )
    
    # Natijalarni guruhga e'lon qilish
    if killed_player:
        text = (
            f"🌅 <b>Tong otdi! {game.day}-kun</b>\n\n"
            f"💀 <b>{killed_player.display}</b> o'ldirildi!\n"
            f"Uning roli: {ROLE_ICON.get(killed_player.role, '❓')} <b>{killed_player.role}</b>\n\n"
        )
    elif game.healed_player:
        healed = game.get_player(game.healed_player)
        text = (
            f"🌅 <b>Tong otdi! {game.day}-kun</b>\n\n"
            f"💊 Doktor {healed.display} ni davoladi! Hech kim o'lmadi!\n\n"
        )
    else:
        text = (
            f"🌅 <b>Tong otdi! {game.day}-kun</b>\n\n"
            f"Bu tun hech kim o'lmadi...\n\n"
        )
    
    # Tirik qolganlar
    alive_list = "\n".join([
        f"{'👤' if p.team == 'village' else '🔪'} {p.display}"
        for p in game.alive_players
    ])
    text += f"<b>Tirik o'yinchilar ({len(game.alive_players)}):</b>\n{alive_list}\n\n"
    
    # G'olibni tekshirish
    winner = check_winner(game)
    if winner:
        await end_game(game, bot, winner)
        return
    
    text += f"⏱ Ovoz berish vaqti: {DAY_TIME} soniya"
    
    # Ovoz berish uchun inline tugmalar
    kb = make_players_keyboard(game.alive_players, f"d_vote:{game.day}", columns=2)
    kb.inline_keyboard.append([
        InlineKeyboardButton("⏭ O'tkazib yuborish", callback_data=f"d_skip:{game.day}")
    ])
    
    if game.game_msg_id:
        await safe_edit_message(bot, game.chat_id, game.game_msg_id, text, reply_markup=kb)
    else:
        sent = await bot.send_message(game.chat_id, text, reply_markup=kb, parse_mode="HTML")
        game.game_msg_id = sent.message_id
    
    game.reset_day()
    
    # Kun uchun timer
    game.day_task = asyncio.create_task(day_timer(game, bot))


# ═══════════════════════════════════════════
#  9. KUN FAZASI (OVOZ BERISH)
# ═══════════════════════════════════════════

async def day_timer(game: MafiaGame, bot: Bot):
    """Kun timer. DAY_TIME soniyadan keyin ovoz berishni yakunlaydi."""
    try:
        await asyncio.sleep(DAY_TIME)
        await end_day_phase(game, bot)
    except asyncio.CancelledError:
        pass
    except Exception as e:
        logging.error(f"Day timer error: {e}")


async def end_day_phase(game: MafiaGame, bot: Bot):
    """Kun fazasini yakunlash va ovozlarni hisoblash."""
    if game.phase != "day":
        return
    
    # Ovozlarni hisoblash
    votes = {}
    for player in game.alive_players:
        if player.vote is not None and player.vote > 0:
            target_id = player.vote
            votes[target_id] = votes.get(target_id, 0) + 1
    
    eliminated = None
    if votes:
        max_votes = max(votes.values())
        top_voted = [t for t, v in votes.items() if v == max_votes]
        elim_id = random.choice(top_voted)
        eliminated = game.get_player(elim_id)
        if eliminated:
            eliminated.alive = False
    
    # Natijalarni e'lon qilish
    text = (
        f"🌅 <b>{game.day}-kun yakunlandi!</b>\n\n"
    )
    
    if eliminated:
        text += (
            f"🗳 <b>{eliminated.display}</b> eng ko'p ovoz oldi!\n"
            f"Uning roli: {ROLE_ICON.get(eliminated.role, '❓')} <b>{eliminated.role}</b>\n\n"
        )
    else:
        text += "Hech kim ovoz bermadi... Hech kim chetlatilmadi.\n\n"
    
    alive_list = "\n".join([
        f"{'👤' if p.team == 'village' else '🔪'} {p.display}"
        for p in game.alive_players
    ])
    text += f"<b>Tirik o'yinchilar ({len(game.alive_players)}):</b>\n{alive_list}\n\n"
    
    if game.game_msg_id:
        await safe_edit_message(bot, game.chat_id, game.game_msg_id, text)
    
    # G'olibni tekshirish
    winner = check_winner(game)
    if winner:
        await end_game(game, bot, winner)
        return
    
    # Keyingi tunni boshlash
    text += f"🌙 <b>{game.day + 1}-tun boshlandi!</b>\nMaxsus rollar PM dan harakat qiling."
    
    if game.game_msg_id:
        await safe_edit_message(bot, game.chat_id, game.game_msg_id, text)
    
    await start_night_phase(game, bot)


async def end_game(game: MafiaGame, bot: Bot, winner: str):
    """O'yinni yakunlash va natijalarni saqlash."""
    game.phase = "ended"
    game.winner = winner
    
    # Ballarni hisoblash
    for player in game.players.values():
        profile = get_profile(player.user_id)
        profile["games"] = profile.get("games", 0) + 1
        
        if winner == player.team:
            profile["wins"] = profile.get("wins", 0) + 1
            update_weekly_score(player.user_id, 3)  # G'alaba = 3 ball
        else:
            profile["losses"] = profile.get("losses", 0) + 1
            update_weekly_score(player.user_id, 1)  # Ishtirok = 1 ball
        
        save_profile(player.user_id, profile)
    
    # G'alaba xabari
    winner_text = "🔪 <b>MAFIA</b>" if winner == "mafia" else "👤 <b>VILLAGE</b>"
    text = (
        f"🏆 <b>O'YIN TUGADI!</b> 🏆\n\n"
        f"G'olib: {winner_text}\n\n"
        f"<b>Barcha rol va o'yinchilar:</b>\n{game.get_roles_text()}\n\n"
        f"O'yin tugadi. Yangi o'yin uchun /mafia yozing."
    )
    
    if game.game_msg_id:
        await safe_edit_message(bot, game.chat_id, game.game_msg_id, text)
    else:
        await bot.send_message(game.chat_id, text, parse_mode="HTML")
    
    # O'yinni xotiradan o'chirish
    if game.chat_id in games:
        del games[game.chat_id]


# ═══════════════════════════════════════════
#  10. INLINE TUGMA HANDLERLARI
# ═══════════════════════════════════════════

async def handle_callback(callback: CallbackQuery, bot: Bot):
    """Barcha inline tugmalar uchun asosiy handler."""
    data = callback.data
    user_id = callback.from_user.id
    chat_id = callback.message.chat.id if callback.message else 0
    
    # Callback'ni javobini berish (loading'ni to'xtatish)
    try:
        await callback.answer()
    except:
        pass
    
    # ── START MENYU ──
    if data == "profile":
        await show_profile(callback, bot)
        return
    elif data == "top":
        await show_top(callback, bot)
        return
    elif data == "stats":
        await show_stats(callback, user_id, bot)
        return
    elif data == "help":
        await show_help(callback, bot)
        return
    
    # ── O'YIN REGISTRATSIYASI ──
    elif data.startswith("join:"):
        await handle_join_callback(callback, bot)
        return
    elif data.startswith("leave:"):
        await handle_leave_callback(callback, bot)
        return
    
    # ── TUN HARAKATLARI ──
    elif data.startswith("nv_kill:"):
        # Mafia o'ldirish ovozi
        await handle_night_kill(callback, bot)
        return
    elif data.startswith("nv_don:"):
        # Don o'ldirish ovozi
        await handle_night_don(callback, bot)
        return
    elif data.startswith("nv_check:"):
        # Komissar tekshiruvi
        await handle_night_check(callback, bot)
        return
    elif data.startswith("nv_heal:"):
        # Doktor davolash
        await handle_night_heal(callback, bot)
        return
    
    # ── KUN OVOZ BERISH ──
    elif data.startswith("d_vote:"):
        await handle_day_vote(callback, bot)
        return
    elif data.startswith("d_skip:"):
        await handle_day_skip(callback, bot)
        return
    
    elif data == "back_menu":
        # Asosiy menyuga qaytish
        await callback.answer()
        user = callback.from_user
        text = (
            f"🌙 <b>NIGHT KILLERS</b>\n\n"
            f"Assalomu alaykum, {user.first_name}!\n\n"
            f"👤 Profil, 🏆 Reyting, 📊 Statistika — barchasi shu yerda.\n"
            f"O'ynash uchun guruhga /mafia yozing!"
        )
        kb = make_inline_keyboard([
            [InlineKeyboardButton("👤 Profil", callback_data="profile"),
             InlineKeyboardButton("🏆 Reyting", callback_data="top")],
            [InlineKeyboardButton("📊 Statistika", callback_data="stats"),
             InlineKeyboardButton("📖 Yordam", callback_data="help")],
        ])
        await safe_edit_message(
            bot, callback.message.chat.id,
            callback.message.message_id, text, reply_markup=kb
        )
        return


async def show_profile(callback: CallbackQuery, bot: Bot):
    """Foydalanuvchi profilini ko'rsatish."""
    user = callback.from_user
    profile = get_profile(user.id, user.first_name, user.username or "")
    
    text = (
        f"👤 <b>{user.first_name}</b>\n\n"
        f"💎 Olmos: <b>{profile.get('olmos', 0)}</b>\n"
        f"💵 Dollar: <b>{profile.get('dollars', 0)}</b>\n"
        f"💶 Evro: <b>{profile.get('evro', 0)}</b>\n\n"
        f"🎮 O'yinlar: <b>{profile.get('games', 0)}</b>\n"
        f"🏆 G'alaba: <b>{profile.get('wins', 0)}</b>\n"
        f"💔 Mag'lubiyat: <b>{profile.get('losses', 0)}</b>\n"
        f"📈 G'alaba %: <b>{profile.get('wins',0)/max(profile.get('games',0),1)*100:.1f}%</b>\n"
    )
    
    # Haftalik unvon
    titles = get_weekly_titles_dict()
    if user.id in titles:
        text += f"\n🏅 <b>Unvon:</b> {titles[user.id]['title']}"
    
    kb = make_inline_keyboard([
        [InlineKeyboardButton("🔙 Orqaga", callback_data="back_menu")]
    ])
    
    await safe_edit_message(
        bot, callback.message.chat.id,
        callback.message.message_id, text, reply_markup=kb
    )


async def show_top(callback: CallbackQuery, bot: Bot):
    """Haftalik reytingni ko'rsatish."""
    top_players = get_weekly_top(20)
    
    text = "🏆 <b>HAFTALIK REYTING</b> 🏆\n\n"
    if not top_players:
        text += "Bu hafta hali hech kim o'ynamadi.\n"
    else:
        for i, p in enumerate(top_players, 1):
            name = p.get("name") or f"ID:{p['user_id']}"
            text += f"{i}. {name}: {p['score']} ball\n"
    
    text += (
        "\n🎁 <b>Sovrinlar (hafta oxirida):</b>\n"
        "🥇 Top 1: 👑 <b>\"Don Corleone\"</b> unvoni\n"
        "🥈 Top 2: 🎯 <b>\"Soyadagi Strateg\"</b> unvoni\n"
    )
    
    kb = make_inline_keyboard([
        [InlineKeyboardButton("🔙 Orqaga", callback_data="back_menu")]
    ])
    
    await safe_edit_message(
        bot, callback.message.chat.id,
        callback.message.message_id, text, reply_markup=kb
    )


async def show_stats(callback: CallbackQuery, user_id: int, bot: Bot):
    """Shaxsiy statistika."""
    profile = get_profile(user_id)
    games_count = profile.get('games', 0)
    wins = profile.get('wins', 0)
    losses = profile.get('losses', 0)
    pct = wins / max(games_count, 1) * 100
    
    text = (
        f"📊 <b>Statistika</b>\n\n"
        f"🎮 O'yinlar: <b>{games_count}</b>\n"
        f"🏆 G'alaba: <b>{wins}</b>\n"
        f"💔 Mag'lubiyat: <b>{losses}</b>\n"
        f"📈 G'alaba %: <b>{pct:.1f}%</b>"
    )
    
    kb = make_inline_keyboard([
        [InlineKeyboardButton("🔙 Orqaga", callback_data="back_menu")]
    ])
    
    await safe_edit_message(
        bot, callback.message.chat.id,
        callback.message.message_id, text, reply_markup=kb
    )


async def show_help(callback: CallbackQuery, bot: Bot):
    """Yordam matni."""
    text = (
        "📖 <b>Yordam</b>\n\n"
        "🎮 <b>O'yin buyruqlari (guruhda):</b>\n"
        "/mafia — O'yin yaratish\n"
        "/join — Qo'shilish\n"
        "/leave — Chiqish\n"
        "/startgame — Boshlash (admin)\n"
        "/cancel — O'yinni bekor qilish (admin)\n\n"
        "🌙 <b>Tun fazasi:</b>\n"
        "• Mafia va Don — kimni o'ldirishni tanlaydi\n"
        "• Komissar — kimni tekshirishni tanlaydi\n"
        "• Doktor — kimni davolashni tanlaydi\n"
        "• Tinch aholi — tun bo'yi uxlaydi\n\n"
        "☀️ <b>Kun fazasi:</b>\n"
        "• Natijalar e'lon qilinadi\n"
        "• Ovoz berish orqali o'yinchi chetlatiladi\n\n"
        "👤 <b>Shaxsiy buyruqlar:</b>\n"
        "/start — Botni ishga tushirish\n"
        "/profile — Profil\n"
        "/top — Haftalik reyting\n\n"
        "🏆 <b>Haftalik unvonlar:</b>\n"
        "🥇 Top 1: Don Corleone\n"
        "🥈 Top 2: Soyadagi Strateg"
    )
    
    kb = make_inline_keyboard([
        [InlineKeyboardButton("🔙 Orqaga", callback_data="back_menu")]
    ])
    
    await safe_edit_message(
        bot, callback.message.chat.id,
        callback.message.message_id, text, reply_markup=kb
    )


async def handle_join_callback(callback: CallbackQuery, bot: Bot):
    """Joingame tugmasi orqali o'yinga qo'shilish."""
    user = callback.from_user
    parts = callback.data.split(":")
    if len(parts) < 2:
        await callback.answer("Xatolik yuz berdi!", show_alert=True)
        return
    
    try:
        target_chat = int(parts[1])
    except ValueError:
        await callback.answer("Xatolik yuz berdi!", show_alert=True)
        return
    
    if target_chat not in games:
        await callback.answer("O'yin mavjud emas!", show_alert=True)
        return
    
    game = games[target_chat]
    if game.phase != "registration":
        await callback.answer("Ro'yxatdan o'tish tugagan!", show_alert=True)
        return
    
    if user.id in game.players:
        await callback.answer("Siz allaqachon o'yindasiz!", show_alert=True)
        return
    
    if len(game.players) >= MAX_PLAYERS:
        await callback.answer("O'yin to'liq!", show_alert=True)
        return
    
    game.players[user.id] = Player(user.id, user.first_name, user.username or "")
    await update_game_message(game, bot)
    await callback.answer("✅ O'yinga qo'shildingiz!")


async def handle_leave_callback(callback: CallbackQuery, bot: Bot):
    """O'yindan chiqish tugmasi."""
    user_id = callback.from_user.id
    parts = callback.data.split(":")
    if len(parts) < 2:
        await callback.answer("Xatolik!", show_alert=True)
        return
    
    try:
        target_chat = int(parts[1])
    except ValueError:
        await callback.answer("Xatolik!", show_alert=True)
        return
    
    if target_chat not in games:
        await callback.answer("O'yin mavjud emas!", show_alert=True)
        return
    
    game = games[target_chat]
    if game.phase != "registration":
        await callback.answer("Ro'yxatdan o'tish tugagan!", show_alert=True)
        return
    
    if user_id not in game.players:
        await callback.answer("Siz o'yinda emassiz!", show_alert=True)
        return
    
    del game.players[user_id]
    await update_game_message(game, bot)
    await callback.answer("✅ O'yindan chiqdingiz!")


# ── TUN HARAKATLARI ──


async def handle_night_kill(callback: CallbackQuery, bot: Bot):
    """Mafia o'ldirish ovozi."""
    user_id = callback.from_user.id
    parts = callback.data.split(":")
    if len(parts) < 2:
        await callback.answer("Xatolik!", show_alert=True)
        return
    
    try:
        target_id = int(parts[2]) if len(parts) > 2 else int(parts[1])
    except (ValueError, IndexError):
        await callback.answer("Xatolik!", show_alert=True)
        return
    
    # O'yinchini topish
    game = None
    for g in games.values():
        if user_id in g.players and g.phase == "night":
            game = g
            break
    
    if not game:
        await callback.answer("Siz o'yinda emassiz yoki tun emas!", show_alert=True)
        return
    
    player = game.get_player(user_id)
    if not player or not player.alive:
        await callback.answer("Siz o'lgansiz!", show_alert=True)
        return
    
    if player.role != "Mafia":
        await callback.answer("Siz mafia emassiz!", show_alert=True)
        return
    
    if user_id in game.mafia_votes:
        await callback.answer("Siz allaqachon ovoz berdingiz!", show_alert=True)
        return
    
    target = game.get_player(target_id)
    if not target or not target.alive:
        await callback.answer("Bu o'yinchi tirik emas!", show_alert=True)
        return
    
    if target.team == "mafia":
        await callback.answer("Siz mafia a'zosiga ovoz berolmaysiz!", show_alert=True)
        return
    
    game.mafia_votes[user_id] = target_id
    game.action_ready[user_id] = True
    
    await callback.answer(f"✅ {target.display} ga ovoz berildi!")
    
    # Xabarni yangilash (tugmalarni o'chirish)
    try:
        await callback.message.edit_text(
            f"✅ Ovoz berildi: {target.display}\n\nBoshqa mafia a'zolarining qarorini kuting...",
            parse_mode="HTML"
        )
    except:
        pass


async def handle_night_don(callback: CallbackQuery, bot: Bot):
    """Don o'ldirish ovozi."""
    user_id = callback.from_user.id
    parts = callback.data.split(":")
    if len(parts) < 2:
        await callback.answer("Xatolik!", show_alert=True)
        return
    
    try:
        target_id = int(parts[2]) if len(parts) > 2 else int(parts[1])
    except (ValueError, IndexError):
        await callback.answer("Xatolik!", show_alert=True)
        return
    
    game = None
    for g in games.values():
        if user_id in g.players and g.phase == "night":
            game = g
            break
    
    if not game:
        await callback.answer("Siz o'yinda emassiz yoki tun emas!", show_alert=True)
        return
    
    player = game.get_player(user_id)
    if not player or not player.alive:
        await callback.answer("Siz o'lgansiz!", show_alert=True)
        return
    
    if player.role != "Don":
        await callback.answer("Siz Don emassiz!", show_alert=True)
        return
    
    if game.don_target is not None:
        await callback.answer("Siz allaqachon tanladingiz!", show_alert=True)
        return
    
    target = game.get_player(target_id)
    if not target or not target.alive:
        await callback.answer("Bu o'yinchi tirik emas!", show_alert=True)
        return
    
    if target.team == "mafia":
        await callback.answer("Siz mafia a'zosini o'ldirolmaysiz!", show_alert=True)
        return
    
    game.don_target = target_id
    game.action_ready[user_id] = True
    
    await callback.answer(f"✅ {target.display} tanlandi!")
    
    try:
        await callback.message.edit_text(
            f"✅ Tanlandi: {target.display}\n\nBoshqa mafia a'zolarining qarorini kuting...",
            parse_mode="HTML"
        )
    except:
        pass


async def handle_night_check(callback: CallbackQuery, bot: Bot):
    """Komissar tekshiruvi."""
    user_id = callback.from_user.id
    parts = callback.data.split(":")
    if len(parts) < 2:
        await callback.answer("Xatolik!", show_alert=True)
        return
    
    try:
        target_id = int(parts[2]) if len(parts) > 2 else int(parts[1])
    except (ValueError, IndexError):
        await callback.answer("Xatolik!", show_alert=True)
        return
    
    game = None
    for g in games.values():
        if user_id in g.players and g.phase == "night":
            game = g
            break
    
    if not game:
        await callback.answer("Siz o'yinda emassiz yoki tun emas!", show_alert=True)
        return
    
    player = game.get_player(user_id)
    if not player or not player.alive:
        await callback.answer("Siz o'lgansiz!", show_alert=True)
        return
    
    if player.role != "Komissar":
        await callback.answer("Siz Komissar emassiz!", show_alert=True)
        return
    
    if game.komissar_target is not None:
        await callback.answer("Siz allaqachon tekshirdingiz!", show_alert=True)
        return
    
    target = game.get_player(target_id)
    if not target or not target.alive:
        await callback.answer("Bu o'yinchi tirik emas!", show_alert=True)
        return
    
    game.komissar_target = target_id
    game.action_ready[user_id] = True
    
    # Natijani darhol yuborish
    is_mafia = target.team == "mafia"
    result = "🔴 MAFIA" if is_mafia else "🟢 Tinch aholi"
    
    await callback.answer(f"✅ Natija: {result}!")
    
    try:
        await callback.message.edit_text(
            f"🔍 <b>Tekshiruv natijasi:</b>\n"
            f"{target.display}: {result}",
            parse_mode="HTML"
        )
    except:
        pass


async def handle_night_heal(callback: CallbackQuery, bot: Bot):
    """Doktor davolash."""
    user_id = callback.from_user.id
    parts = callback.data.split(":")
    if len(parts) < 2:
        await callback.answer("Xatolik!", show_alert=True)
        return
    
    try:
        target_id = int(parts[2]) if len(parts) > 2 else int(parts[1])
    except (ValueError, IndexError):
        await callback.answer("Xatolik!", show_alert=True)
        return
    
    game = None
    for g in games.values():
        if user_id in g.players and g.phase == "night":
            game = g
            break
    
    if not game:
        await callback.answer("Siz o'yinda emassiz yoki tun emas!", show_alert=True)
        return
    
    player = game.get_player(user_id)
    if not player or not player.alive:
        await callback.answer("Siz o'lgansiz!", show_alert=True)
        return
    
    if player.role != "Doktor":
        await callback.answer("Siz Doktor emassiz!", show_alert=True)
        return
    
    if game.doktor_target is not None:
        await callback.answer("Siz allaqachon davoladingiz!", show_alert=True)
        return
    
    target = game.get_player(target_id)
    if not target or not target.alive:
        await callback.answer("Bu o'yinchi tirik emas!", show_alert=True)
        return
    
    game.doktor_target = target_id
    game.action_ready[user_id] = True
    
    await callback.answer(f"✅ {target.display} davolanadi!")
    
    try:
        await callback.message.edit_text(
            f"💊 <b>Davolash qabul qilindi</b>\n\n{target.display} himoya qilinadi.",
            parse_mode="HTML"
        )
    except:
        pass


# ── KUN OVOZ BERISH ──


async def handle_day_vote(callback: CallbackQuery, bot: Bot):
    """Kun davomida ovoz berish."""
    user_id = callback.from_user.id
    parts = callback.data.split(":")
    if len(parts) < 2:
        await callback.answer("Xatolik!", show_alert=True)
        return
    
    try:
        target_id = int(parts[2]) if len(parts) > 2 else int(parts[1])
    except (ValueError, IndexError):
        await callback.answer("Xatolik!", show_alert=True)
        return
    
    # O'yinchining chat_id sini topish
    # Callback query chat_id orqali o'yinni topamiz
    chat_id = callback.message.chat.id
    if chat_id not in games:
        await callback.answer("O'yin mavjud emas!", show_alert=True)
        return
    
    game = games[chat_id]
    if game.phase != "day":
        await callback.answer("Hozir ovoz berish vaqti emas!", show_alert=True)
        return
    
    player = game.get_player(user_id)
    if not player or not player.alive:
        await callback.answer("Siz o'lgansiz yoki o'yinda emassiz!", show_alert=True)
        return
    
    if player.vote is not None:
        await callback.answer("Siz allaqachon ovoz bergansiz!", show_alert=True)
        return
    
    target = game.get_player(target_id)
    if not target or not target.alive:
        await callback.answer("Bu o'yinchi tirik emas!", show_alert=True)
        return
    
    player.vote = target_id
    
    await callback.answer(f"✅ {target.display} ga ovoz berdingiz!")
    
    try:
        await callback.message.edit_text(
            f"✅ Siz {target.display} ga ovoz berdingiz!\n\nNatijalarni kuting...",
            parse_mode="HTML"
        )
    except:
        pass


async def handle_day_skip(callback: CallbackQuery, bot: Bot):
    """Ovoz berishni o'tkazib yuborish."""
    user_id = callback.from_user.id
    parts = callback.data.split(":")
    day_num = int(parts[1]) if len(parts) > 1 else 0
    
    chat_id = callback.message.chat.id
    if chat_id not in games:
        await callback.answer("O'yin mavjud emas!", show_alert=True)
        return
    
    game = games[chat_id]
    if game.phase != "day":
        await callback.answer("Hozir ovoz berish vaqti emas!", show_alert=True)
        return
    
    player = game.get_player(user_id)
    if not player or not player.alive:
        await callback.answer("Siz o'lgansiz!", show_alert=True)
        return
    
    if player.vote is not None:
        await callback.answer("Siz allaqachon ovoz bergansiz!", show_alert=True)
        return
    
    player.vote = -1  # O'tkazib yuborish
    
    await callback.answer("✅ Ovoz bermadingiz!")
    
    try:
        await callback.message.edit_text(
            "✅ Ovoz berish o'tkazib yuborildi.",
            parse_mode="HTML"
        )
    except:
        pass


# ═══════════════════════════════════════════
#  11. HAFTALIK BALLAR VA UNVONLAR
# ═══════════════════════════════════════════

async def distribute_weekly_prizes(bot: Bot):
    """Hafta oxirida sovrinlarni taqsimlash.
    Bu funksiya har hafta dushanba kuni avtomatik chaqiriladi."""
    
    week_num = datetime.now().isocalendar()[1]
    previous_week = week_num - 1 if week_num > 1 else 52
    
    top_players = get_weekly_top(2)
    
    if len(top_players) >= 1:
        # Top 1: Don Corleone
        top1 = top_players[0]
        save_weekly_title(top1["user_id"], "Don Corleone", previous_week)
        
        # Top 1 ga sovrin
        profile = get_profile(top1["user_id"])
        profile["olmos"] = profile.get("olmos", 0) + 45
        save_profile(top1["user_id"], profile)
        
        try:
            await bot.send_message(
                top1["user_id"],
                f"🏆 <b>Tabriklaymiz!</b>\n\n"
                f"Siz haftaning eng yaxshi o'yinchisi bo'ldingiz!\n"
                f"👑 Unvon: <b>\"Don Corleone\"</b>\n"
                f"🎁 Sovrin: 45💎 Olmos",
                parse_mode="HTML"
            )
        except:
            pass
    
    if len(top_players) >= 2:
        # Top 2: Soyadagi Strateg
        top2 = top_players[1]
        save_weekly_title(top2["user_id"], "Soyadagi Strateg", previous_week)
        
        profile = get_profile(top2["user_id"])
        profile["olmos"] = profile.get("olmos", 0) + 10
        save_profile(top2["user_id"], profile)
        
        try:
            await bot.send_message(
                top2["user_id"],
                f"🏆 <b>Tabriklaymiz!</b>\n\n"
                f"Siz haftaning 2-o'yinchisi bo'ldingiz!\n"
                f"🎯 Unvon: <b>\"Soyadagi Strateg\"</b>\n"
                f"🎁 Sovrin: 10💎 Olmos",
                parse_mode="HTML"
            )
        except:
            pass


async def weekly_check_job(bot: Bot):
    """Har soatda ishlaydi va hafta o'zgarganini tekshiradi.
    Hafta o'zgarganda (dushanba) avtomatik ravishda sovrinlarni taqsimlaydi."""
    last_week = 0
    while True:
        try:
            current_week = datetime.now().isocalendar()[1]
            if current_week != last_week:
                if last_week != 0:  # Birinchi marta emas, hafta o'zgargan
                    await distribute_weekly_prizes(bot)
                last_week = current_week
        except Exception as e:
            logging.error(f"Weekly check error: {e}")
        await asyncio.sleep(3600)  # Har soatda tekshiradi


# ═══════════════════════════════════════════
#  12. ADMIN KOMANDALARI
# ═══════════════════════════════════════════

async def cmd_give(message: Message, bot: Bot):
    """Admin: o'yinchiga olmos berish. /give @user sum"""
    if message.from_user.id != ADMIN_ID:
        await message.answer("❌ Faqat admin!")
        return
    
    args = message.text.split()
    if len(args) < 3:
        await message.answer("❌ /give @user sum")
        return
    
    # Username yoki ID ni topish
    target_text = args[1].replace("@", "")
    try:
        amount = int(args[2])
    except ValueError:
        await message.answer("❌ Son yozing!")
        return
    
    if amount <= 0 or amount > 100000:
        await message.answer("❌ 1-100000 oralig'ida son yozing!")
        return
    
    # User ID ni topish
    target_id = None
    if args[1].startswith("@"):
        # Username bo'yicha qidirish
        for uid, p in get_all_profiles().items():
            if p.get("username", "").lower() == target_text.lower():
                target_id = uid
                break
        if target_id is None:
            await message.answer("❌ Foydalanuvchi topilmadi!")
            return
    else:
        try:
            target_id = int(args[1])
        except ValueError:
            await message.answer("❌ ID yoki @username yozing!")
            return
    
    profile = get_profile(target_id)
    profile["olmos"] = profile.get("olmos", 0) + amount
    save_profile(target_id, profile)
    
    await message.answer(f"✅ {amount}💎 olmos berildi (ID: {target_id})")
    
    try:
        await bot.send_message(
            target_id,
            f"🎁 Sizga {amount}💎 olmos berildi!"
        )
    except:
        pass


def get_all_profiles() -> dict:
    """Barcha profillarni olish."""
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute("SELECT * FROM profiles").fetchall()
        return {r["user_id"]: dict(r) for r in rows}


# ═══════════════════════════════════════════
#  13. BOTNI ISHGA TUSHIRISH
# ═══════════════════════════════════════════

async def setup_bot():
    """Botni sozlash va ishga tushirish."""
    global bot_instance, dp_instance
    
    # Ma'lumotlar bazasini yaratish
    init_db()
    
    # Bot va Dispatcherni yaratish
    bot = Bot(token=TOKEN, default=DefaultBotProperties(parse_mode="HTML"))
    dp = Dispatcher()
    
    bot_instance = bot
    dp_instance = dp
    
    # Handlerlarni ro'yxatdan o'tkazish
    dp.message.register(cmd_start, Command("start"))
    dp.message.register(cmd_mafia, Command("mafia"))
    dp.message.register(cmd_join, Command("join"))
    dp.message.register(cmd_leave, Command("leave"))
    dp.message.register(cmd_startgame, Command("startgame"))
    dp.message.register(cmd_cancel, Command("cancel"))
    dp.message.register(cmd_give, Command("give"))
    
    # Inline callback handler
    dp.callback_query.register(handle_callback)
    
    # Haftalik tekshiruvni boshlash
    asyncio.create_task(weekly_check_job(bot))
    
    print("[OK] Bot ishga tushdi!")
    print(f"[INFO] Admin ID: {ADMIN_ID}")
    
    # Botni polling rejimida ishga tushirish
    await dp.start_polling(bot, skip_updates=True)


def main():
    """Asosiy funksiya."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    
    try:
        asyncio.run(setup_bot())
    except (KeyboardInterrupt, SystemExit):
        print("\n[OK] Bot to'xtatildi.")


if __name__ == "__main__":
    main()
