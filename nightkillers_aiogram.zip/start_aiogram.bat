@echo off
set BOT_TOKEN=8928310354:AAHQ_jAuUqxfWH3Zz5NRAyqBs9YnShmo2CQ
set CARD_NUMBER=4073-4200-7154-7032
cd /d D:\3D
start /min "" "C:\Users\RZ\AppData\Local\Python\bin\python.exe" mafia_bot_aiogram.py
